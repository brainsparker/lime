# Codex selected async question：布局、timeline 与答案行

只读研究，未修改 Lime 仓库源码，未构建，未启动 Codex 或 Lime Electron。`targetExecuted=false`。
目标为 Codex Desktop `26.1007.30912 / 20156`，安装载体 `/Applications/ChatGPT.app/Contents/Resources/app.asar`。
本轮重新核对 ASAR SHA-256：`75e397e2280dde93b70a85aa926f4282c728eacc84dfeb15ba7fb6ddd84628af`。
所有 span 为完整原件 UTF-16 半开区间；压缩符号只用于定位，不能迁入 Lime 作为上游开发命名。

## 多题 timeline 的真实投影

shared `d1 [4984671,5003537)` 的 `agentMessage` 分支，在 `requestUserInputAsyncUiEnabled && qH(item)` 时，以 `Bmn(item).map(...)` 替代原始全文行：每个 question 单独生成一条 `assistant-message`。

```js
{
  type: "assistant-message",
  searchItemId: question.id,
  content: question.title,
  completed: true,
  phase: source.phase,
  delivery: source.delivery,
  requestUserInputAsync: {
    sourceItemId: question.sourceItemId,
    questionIndex: question.questionIndex
  },
  responseAnnotationTargetId: source.id
}
```

同 source 原件全文不会再额外 push 一行。`qH [3259321,3259396)` 检查 `type=agentMessage` 且 questions 非空；不以 delivery 作为题目存在的判断。`Bmn [3259396,3259537)` 按 questions index 派生；`F5t [2660569,2660643)` 的稳定派生 ID 为 `JSON.stringify(["request_user_input_async",sourceItemId,index])`。

sites `CO [332497,332902)` 对此类 assistant row 返回 `requestUserInputAsync.sourceItemId`，用于读取 canonical 原件；`bO [327323,331353)` 再按 questionIndex 从 `canonical.questions[index].title` 更新当前正文。正文仍走普通 assistant renderer `xx [103393,119550)`，只展示本题 title；options 留在逐题问答表单，不渲染成 timeline 选项列表。`xx` 仅在 questionIndex 为 0 时保留该组 sentAt 展示。

因此 Lime 应在既有 canonical item → timeline segment owner 内展开每题 projection，以派生 qid 作 segment 身份，以 sourceItemId 读原件；不能同时保留原 text 全文，也不能在全文行下堆多个 Answer 按钮。

## 未答题目入口与完整判定

sites `vO [325545,327090)` 仅在以下条件全部满足时，以 `bv` 包裹该 assistant row：

- `type === "assistant-message"`；
- `requestUserInputAsync != null`；
- `!isReadOnly`；
- historyEntityKey、searchItemId 均存在。

questionKey 为 `{hostId,threadId:conversationId,entityKey:historyEntityKey,itemId:searchItemId}`，其中 itemId 是派生 qid。

primary `Tz [531366,531976)` 中的 `M$e`（export Pp → sites Bf）完整 selector：

```js
const ids = get(TIt, {hostId,threadId,entityKey});
const draft = get(WS, questionKey);
if (!ids.includes(itemId) || draft == null ||
    get(Evn, {hostId,threadId,entityKey}) !== "inProgress") {
  return "message";
}
const selection = get(OIt, {hostId,threadId});
return draft.lastSubmission != null ||
  (selection?.selectedQuestionKey.entityKey === entityKey &&
   selection.questionIds.includes(itemId))
  ? "message" : "answer";
```

没有 `isSkipped` 检查：已跳过但未回答的题目可以通过此手动入口再次选择。自动选题与路由入口有各自的 skipped gate，不能混入该 selector。TIt 在 `GS [1328107,1328676)` 中订阅 US，并经 lIt → mIt 从 canonical turn/items 同步全题集合；Evn 返回 canonical entity 的 status。TIt 不是剩余未答题集合。

`bv [46644,47294)` 仅在 selector 为 answer 时，在助手正文下方渲染：`className="mt-3"`、`color="outlineGhost"`、`size="composer"`，内容为 icon（shared export Xv）与 `sendUserMessageQuestion.answer / "Answer question"`。点击后再次读取相同 selector，仍为 answer 才调用 initial `gIt [1326539,1326696)`（export pKn → sites wd）。gIt 确认 WS 存在，将 selection 设为当前 questionKey，questionIds 仅该题。

已答题目不会由此模板显示额外重开按钮。initial `ikc [10102860,10104815)` 的 `openRequestUserInputAsyncQuestion` 路由入口同样要求 inProgress、当前 entity、lastSubmission 为空且未 skipped。gIt 底层支持选择已有题稿，不足以证明产品存在已答重开入口。

`P$e [532291,536323)` 仅在 selection 下问题数为 1 且当前 lastSubmission 非空时传入 hasSubmitted；`x$e [525623,530063)` 在末题且 hasSubmitted 时显示 `Send update`。提交期间产生新编辑而保留单题 selection 是已闭合的触达路径；不据此发明已答题目的新按钮。

## 用户答案行模板

shared `owr [4979860,4982567)` 用既有严格 envelope parser tV 生成 `questionReplies`；可回退的 message 文本为粗体题目、换行、答案，各题间空行。sites `nO [296758,323118)` 的 user-message 分支将 `Fv` 作为 `messageContent` 覆盖普通正文。

`Fv [52082,52736)` 的完整 DOM 职责为：

```jsx
<div className="flex flex-col gap-3 text-size-chat">
  {replies.map(({questionItemId,question,answer}) => (
    <div key={questionItemId} className="flex flex-col gap-1">
      <span className="truncate opacity-70" title={H(question)}>
        {H(question)}
      </span>
      <Vg cwd={cwd} hostId={hostId}
          isAeonFormatted={conversationAeonFlag} text={answer} />
    </div>
  ))}
</div>
```

H 为 shared export DUt → `kz [2486566,2486750)`：trim、文本/Markdown转换，并合并空白；不要原样暴露 markup 作为题目标签。Vg 为 `user-message-dd2539189e70.js` export r → `gt [5121,5994)`，复用 `variant="user-message"` 正文 renderer。没有新增答案 textarea、卡片、表格或题下答案副本。

## Composer 最窄合同

selectedQuestionKey 来自 initial GS 的 OIt/kIt，primary wz 是 `get(selectedQuestionKey)!=null`；不是任意 pending interaction 的别名。Qft 将真实 selection（并受自身 blocked 参数 gate）纳入 auto-single-line 模式入口。

chl 的最终优先级：先 base（rhl/ihl），再 `awaiting && !visibleAttachments || !goal && (compact || base.single)`，再 dictation transcript 显示覆写，最后 composition lock 覆写。因此 standard 模式下 selected async question、无可见附件会直接 single-line，即便正文已有换行/多段/overflow；有附件只切断 awaiting 分支，不能笼统声明任何条件下均 multiline。IME 锁住开始 composition 时的最终布局，结束才释放。

overflow 来源是 DOM 测量，包含 editor 纵向 scrollHeight/clientHeight 与 textblock 横向 scrollWidth/clientWidth；ResizeObserver、字体 loadingdone、Controller 订阅触发重测。不应用字符数代替，也不重建 Controller/EditorView。

CSS 原件 `webview/assets/app-initial-99e8b4b455fa.css` SHA-256 为 `1a75f9180b89d2457dc09e4efea288436c9cf6d44e5ba59b2c03d3d571b7bf61`。95 条相关规则的 selector、父 @media/@container、UTF-16 span 和 declarations 在同目录 `lime-selected-question-layout-css.json`。

- footer single-line 三列为 `auto minmax(0,1fr) auto`；multiline 为 `minmax(0,auto) auto minmax(0,1fr)`、gap5px。
- stacked 将输入放第一行全宽，leading/trailing 放底行两端；inline 三槽同一行。默认表面/间距/presentation的正常单行为 responsive，仅 viewport `<40rem` 时 stacked。
- 单行 ProseMirror 使用 white-space pre；p 使用 ellipsis、pre、overflow hidden。单行容器 flex/overflow-hidden，后代 min-width/min-height 0；高度为 `--composer-editor-single-line-height`，fallback `9*--spacing`，不沿用120/136px多行 min-height。
- 多行纵向滚动，max-height 为 `min(25dvh, var(--composer-editor-max-height,25dvh))`，form 分支为 `min(25dvh,7lh)`。
- dictation 隐藏编辑器时保留 DOM，height0/inert/aria-hidden。Body 在附件/reply-context/realtime voice 条件下可独立 multiline，不能把外层、Body、Input/Footer 的布局合并成一个状态。

Lime 窄接线：复用 workspace 已有真实 async selection → QuestionSelectionContext → useComposerLayout；不要接同步 pending 标志。InputbarCore 继续由已有附件集合传 visibleAttachments；ComposerLayout 与 composerStyles 按上述单行分支消除多行最小高度。通用 auto-fit 策略仍需完整实现，不能因 selected 分支已接通就声明全 Composer 对齐。

## Evidence 与保全

本轮新增：

| Evidence | 输入 | 解析 |
| --- | --- | --- |
| ev_c2b5509b493e5e04e3b3676441433bad4398c1386f19e937c69f9697bba0ee40 | rea-input/，7完整声明，8789bytes | 3125 AST nodes，0 parse failures |
| ev_ce5739a29f7e671332e461f9bb11d43096e6b1579bc513de44b1851c8a5a8093 | projection-rea-input/，完整 d1，18866bytes | 5440 AST nodes，0 parse failures |

两次 application inventory coverage complete、无截断遗漏；semantic coverage unknown，分别611与1072个 unknown，关系族 partial。完整声明提取不包含全部模块闭包，跨模块 alias 是完整原件 Acorn AST 核对，不能声称 REA 已证明所有动态调用。`rea-manifest.json` 记录原件摘要、完整 source span、声明摘要和 Evidence 对应关系；完整 CLI JSON 为 `rea-evidence.json`、`projection-rea-evidence.json`。

复用 Evidence：47控制链 `ev_0b3be8d21e101b4df02aae5ed05108e403a702ade047f8bf3b4d022d378aa914`；48 surface `ev_f2b3325f4913e5eb8a5c6ea5f703ac3d62f91a4187872dd3d62ac9d9624ab667`；50模式 `ev_e74e1af289bfe4b44f9d691f18aa79ec95a893d4a5777f632a16322c35804154`；55 overflow `ev_b7fca04b25e3ad1c0bd9ba80ea1778bad6c0db9d5ceff125c2648ca3edb183d2`；async状态/表单 `ev_e4e0901acf437ccf3ed6d3ec29a0096f3b9ab1d80ed85001fe349ae806e73f32` 与 `ev_1a7806e0b5d2303945f372dd300baf8073bc766c6cd3be3277cde9b5307f6ad5`；sites nO/bO/xx 完整原件父记录 `ev_5d90cd5b2a2786d2880ac9d452cf326f7664eeb7ac84ec16a5294c84587e3449` 及 bO补充 `ev_061767f0321a26b09881a8a7698d4ae9fd1107c81911e5efb91c5aa5c8aaa397`。

完整 user-message 原件本轮保全在同目录，SHA-256 `66184e5b9b1fab3a7dc365418d061f9b7e64afaf6fc5aa01c3150fb7b09660b4`，28104bytes。其它完整原件保全位置与摘要见 manifest。没有截图或真实交互证据；运行时开关实际启用、所有动态导航分支、已答题其他潜在入口保持 unknown。没有把静态支持写成运行时已观察。
