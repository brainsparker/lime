import fs from "node:fs";
import { createRequire } from "node:module";
import crypto from "node:crypto";
const root = "/Users/coso/Documents/dev/ai/aiclientproxy/lime";
const require = createRequire(`${root}/package.json`);
const postcss = require("postcss");
const acorn = require("acorn");
const preserve = "/Users/coso/.local/share/rea/analyses/codex-desktop-2026-10-13";
const cssPath = `${preserve}/composer-surface-48/reference.css`;
const css = fs.readFileSync(cssPath, "utf8");
const rules = [];
postcss.parse(css).walkRules(rule => {
  if (!/ComposerLayout(Footer|Input|Body)|AdaptiveFooterInput|SingleLineDictation|RichTextInput/.test(rule.selector)) return;
  const contexts = [];
  for (let p = rule.parent; p; p = p.parent) if (p.type === "atrule") contexts.unshift(`@${p.name} ${p.params}`);
  rules.push({selector:rule.selector, contexts, start:rule.source.start.offset, end:rule.source.end.offset + 1,
    declarations:rule.nodes.filter(n=>n.type === "decl").map(n=>({property:n.prop,value:n.value}))});
});
fs.writeFileSync("/tmp/lime-selected-question-layout-css.json", JSON.stringify({ cssPath, sha256:crypto.createHash("sha256").update(css).digest("hex"), rules }, null, 2)+"\n");
console.log("CSS rules " + rules.length);
for (const [i, rule] of rules.entries()) console.log(`${i}: ${rule.contexts.join(" ")} ${rule.selector} {${rule.declarations.map(n=>n.property+":"+n.value).join(";")}}`);
const primaryPath = `${preserve}/composer-editor-evidence/webview/assets/app-primary-6f60e9ac4103.js`;
const primary = fs.readFileSync(primaryPath, "utf8");
const ast = acorn.parse(primary, { ecmaVersion: "latest", sourceType:"module" });
for (const n of ast.body) {
  if (n.type === "ImportDeclaration") {
    const matches = n.specifiers.filter(s=>["bO","LLe"].includes(s.local.name));
    if(matches.length) console.log(JSON.stringify({import:n.source.value, matches:matches.map(s=>({local:s.local.name,imported:s.imported?.name,start:s.start,end:s.end}))}));
  }
}
const summaryPath = "/tmp/lime-selected-question-layout-mode-summary.json";
if (fs.existsSync(summaryPath)) {
  try {const json=JSON.parse(fs.readFileSync(summaryPath));console.log("REA summary keys " + JSON.stringify(Object.keys(json)));console.log(JSON.stringify(json,null,2).slice(0,1200));}catch(error){console.log("REA summary not JSON: " + String(error));}
}
