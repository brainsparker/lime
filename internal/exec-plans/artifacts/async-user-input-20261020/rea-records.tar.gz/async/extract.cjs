const fs=require('fs'),path=require('path'),crypto=require('crypto'),acorn=require(process.cwd()+'/node_modules/acorn');
const base='/Users/coso/.local/share/rea/analyses/codex-desktop-2026-10-13/';
const out='/tmp/lime-async-user-input-rea-20261020';fs.mkdirSync(out+'/input',{recursive:true});
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const config=[
 ['composer-draft-persistence-artifact/app-shared-8bd9d0399038.js',new Set(['Ktn','qH','Bmn','Vmn','F5t','I5t','tV','nV','V5t','W5t','U5t','G5t','K5t','X5t','Q5t']),[2660569,2663000]],
 ['composer-editor-dependencies/webview/assets/app-initial-6350d04672d0.js',new Set(['GS','mIt','hIt','gIt','_It','vIt','yIt','bIt','xIt','SIt','CIt','HS','lIt','iIt','cIt','pIt']),[1324000,1328700]],
 ['composer-editor-evidence/webview/assets/app-primary-6f60e9ac4103.js',new Set(['P$e','x$e','Tz','N$e','A$e','F$e']),[531300,536400]]
];
const manifest={targetExecuted:false,originalAsarSha256:'75e397e2280dde93b70a85aa926f4282c728eacc84dfeb15ba7fb6ddd84628af',offsetEncoding:'UTF-16 code units',members:[]};
for(const [relative,names,range]of config){const source=fs.readFileSync(base+relative,'utf8'),ast=acorn.parse(source,{ecmaVersion:'latest',sourceType:'module'}),declarations=[],intervals=[];function visit(n){if(!n||typeof n!=='object')return;if(n.type==='FunctionDeclaration'){intervals.push({name:n.id.name,start:n.start,end:n.end});if(names.has(n.id.name)){const text=source.slice(n.start,n.end),file=path.basename(relative)+'-'+n.start+'-'+n.id.name+'.js';fs.writeFileSync(out+'/input/'+file,text);declarations.push({name:n.id.name,start:n.start,end:n.end,path:file,sha256:sha(text)});}}for(const v of Object.values(n)){if(Array.isArray(v))v.forEach(visit);else if(v&&typeof v==='object')visit(v);}}visit(ast);const imports=ast.body.filter(n=>n.type==='ImportDeclaration').flatMap(n=>n.specifiers.map(s=>({local:s.local.name,imported:s.imported?.name??null,source:n.source.value})));fs.writeFileSync(out+'/'+path.basename(relative)+'.imports.json',JSON.stringify(imports));manifest.members.push({path:base+relative,sha256:sha(source),bytes:Buffer.byteLength(source),declarations,nearby:intervals.filter(n=>n.start>=range[0]&&n.start<range[1])});for(const d of declarations)console.log(JSON.stringify(d));}
fs.writeFileSync(out+'/manifest.json',JSON.stringify(manifest,null,2));
